### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlinaKalye/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AlinaKalye/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/19d2e82c83083e2d43dd/maintainability)](https://codeclimate.com/github/AlinaKalye/python-project-49/maintainability)

Игра "Проверка на чётность" запускается командой brain-even. Пользователю показывается случайное число, ему нужно ответить yes, если число чётное, или no — если нечётное.
https://asciinema.org/a/565196
